/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conexion;

/**
 *
 * @author ACER
 */
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ejemplo {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        String usuario = "root";
        String password = "";
        String url = "jdbc:mysql://localhost:3307/usuarios";
        Connection conexion;
        Statement statement;
        ResultSet rs;
        
        try {
            conexion = java.sql.DriverManager.getConnection(url,usuario,password);
            statement = conexion.createStatement();
            rs = statement.executeQuery("select * from usuarios");
            while(rs.next()){
                System.out.println(rs.getString("Nombres"));
            }
            
            //insertar datos
            statement.execute("INSERT INTO `usuarios` (`id_Usuarios`, `Nombres`, `Apellidos`, `Clave`) VALUES ('9', 'isabella', 'gonzalez perez', '7787');");
             System.out.println("");
            rs = statement.executeQuery("select * from usuarios");
            while(rs.next()){
                System.out.println(rs.getString("Nombres"));
            }
            //actulizar datos
            statement.execute("UPDATE `usuarios` SET `Nombres` = 'maria' WHERE `usuarios`.`id_Usuarios` = 4;");
             System.out.println("");
            rs = statement.executeQuery("select * from usuarios");
            while(rs.next()){
                System.out.println(rs.getString("Nombres"));
            }
            
            //eliminacion
            statement.execute("DELETE FROM `usuarios` WHERE `usuarios`.`id_Usuarios` = 2;");
             System.out.println("");
            rs = statement.executeQuery("select * from usuarios");
            while(rs.next()){
                System.out.println(rs.getString("Nombres"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ejemplo.class.getName()).log(Level.SEVERE, null, ex);
        }
        
     
    }
    
}

